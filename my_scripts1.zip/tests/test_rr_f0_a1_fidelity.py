import inspect
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from rr_readout_phase_abc_experiment import BinAffineDistribution
import run_rr_fixed_a1_benchmark as benchmark
import run_rr_jbhi_f0_family as f0_family


def test_historical_a1_is_direct_per_bin_affine() -> None:
    readout = BinAffineDistribution(10)
    assert sorted(readout.state_dict().keys()) == ["bias", "scale"]
    assert sum(p.numel() for p in readout.parameters() if p.requires_grad) == 20


def test_f0_a1_uses_historical_bin_affine_readout() -> None:
    source = inspect.getsource(f0_family.train_a1_readout)
    assert "BinAffineDistribution" in source
    assert "BasisDistributionReadout" not in source


def test_f0_a1_collects_profile_conditioned_spectrum() -> None:
    loader_source = inspect.getsource(f0_family.collect_profile_conditioned_spectral_cache_from_loader)
    windows_source = inspect.getsource(f0_family.collect_profile_conditioned_spectral_cache_from_windows)
    assert "forward_profile_conditioned" in loader_source
    assert "forward_profile_conditioned" in windows_source
    assert "model(imu.float())" not in loader_source
    assert "model(imu)" not in windows_source


def test_standalone_a1_stage_is_disabled(tmp_path) -> None:
    with pytest.raises(SystemExit, match="Standalone A1 is disabled"):
        benchmark.main(["--root", str(tmp_path), "--stages", "a1", "--dry-run"])
